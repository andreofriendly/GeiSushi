<?php
// Database connection parameters
$host = "localhost";
$username = "n1805397_root";
$password = "BM-;al1xn-=e";
$database = "n1805397_gei_sushi";

// Attempt to connect to the database
$koneksi = mysqli_connect($host, $username, $password, $database);

?>